/*
 * Communicaton.h
 *
 *  Created on: Jul 26, 2018
 *      Author: anch
 */

#ifndef COMMUNICATON_H_
#define COMMUNICATON_H_

#include "main.h"

#define ACK							0
#define NACK						1
#define LENGTH_PACKET_DATA        256
#define BOOTLOADER					0
#define APPLICATION					1

typedef enum{
	STATE_REC_HEADER=0,
	STATE_REC_CMD,
	STATE_REC_DATA
}StateReceive_t;


typedef enum{
	CHARGER_ID_1 = 1,
	CHARGER_ID_2,
	CHARGER_ID_3,
	CHARGER_ID_4
}ChargerId_t;

typedef enum{
	ST_READY = 0x01,
	ST_CHARGING,/* 02 */
	ST_ERROR, /* 03 */
	ST_CHARGE_FULL, /* 04 */
	ST_PUSH_PISTON, /* 05 */
	ST_CONTACT_GOOD, /* 06 */
	ST_CONTACT_FAIL /* 07 */
}ChargerState_t;

typedef enum{
	CMD_NONE,
	CMD_GET_ID = 0x01,
	RES_GET_ID, /*0x02 */
	CMD_SET_ID, /*0x03 */
	RES_SET_ID, /*0x04 */
	CMD_GET_STATE, /*0x05 */
	RES_GET_STATE, /*0x06 */
	CMD_GET_BAT_LEVEL, /*0x07 */
	RES_GET_BAT_LEVEL, /*0x08 */
	CMD_START_CHARGE, /*0x09 */
	RES_START_CHARGE, /*0x0A */
	CMD_STOP_CHARGE, /*0x0B */
	RES_STOP_CHARGE, /*0x0C */
}Command_t;

#pragma pack(1)
typedef struct FrameResponseFormat {
	uint16_t header;
	uint8_t command;
	uint16_t length;
	uint8_t ack;
	uint8_t crc;
}FrameResponseFormat_t;
#pragma pack()

#pragma pack(1)
typedef struct CommonPacket{
	uint8_t command;
	uint16_t length;
	uint8_t data[LENGTH_PACKET_DATA+4];
}CommonPacket_t;
#pragma pack()

void CommunicatonInit();

#endif /* COMMUNICATON_H_ */
