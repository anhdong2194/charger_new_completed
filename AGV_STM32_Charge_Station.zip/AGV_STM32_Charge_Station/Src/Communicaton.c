/*
 * Communicaton.cpp
 *
 *  Created on: Jul 26, 2018
 *      Author: anch
 */

#include "Communicaton.h"

FrameResponseFormat_t response;
CommonPacket_t commonPack;
StateReceive_t stateRev;
uint8_t dataRec;
uint8_t* saveData;
uint8_t dataRx;

extern UART_HandleTypeDef huart1;

static uint8_t resGetId();
static uint8_t restSetId(CommonPacket_t* Message);
static uint8_t resGetState();
static uint8_t resBatLevel();
static uint8_t resStartCharge();
static uint8_t resStopCharge();
static uint8_t processCmd(CommonPacket_t *Message);
static void packetProcesssing(uint8_t dataRec);
static void cmdResponse(uint8_t cmd,uint8_t ackRes);
static void cmdResponse_(uint8_t cmd,uint8_t ackRes,uint8_t *data,uint32_t len);
static uint8_t calChecksum(uint8_t* data, uint32_t len);
static uint32_t write(uint8_t* buf, uint32_t length);

void CommunicatonInit()
{
	stateRev = STATE_REC_HEADER;
	memset(&response,0,sizeof(response));
	memset(&commonPack,0,sizeof(commonPack));
	saveData=NULL;
	dataRec=0xFF;
	saveData=(uint8_t*)&commonPack;
	HAL_UART_Receive_IT(&huart1,&dataRx, 1);
}

static uint8_t resGetId() {
	uint8_t id = CHARGER_ID_1; /*Thay bang id cua board*/;
	cmdResponse_(RES_GET_ID,ACK,&id,1);
	return SUCCESS;
}

static uint8_t restSetId(CommonPacket_t* Message) {
	uint8_t idSet = Message->data[0];
	/*set id cho board*/;
	cmdResponse(RES_SET_ID,ACK);
	return SUCCESS;
}

static uint8_t resGetState() {
	uint8_t state = ST_READY; /*Thay bang trang thai hien tai cua board*/;
	cmdResponse_(RES_GET_STATE,ACK,&state,1);
	return SUCCESS;
}

static uint8_t resBatLevel() {
	uint8_t batLevel = 50; /*Thay bang dung luong pin do hien tai*/;
	cmdResponse_(RES_GET_BAT_LEVEL,ACK,&batLevel,1);
	return SUCCESS;
}

static uint8_t resStartCharge() {
	/*bat dau sac*/
	cmdResponse(RES_START_CHARGE,ACK);
	return SUCCESS;
}

static uint8_t resStopCharge() {
	/*dung sac*/
	cmdResponse(RES_STOP_CHARGE,ACK);
	return SUCCESS;
}

static uint8_t processCmd(CommonPacket_t *Message)
{
	switch (Message->command) {
		case CMD_GET_ID:
			return resGetId(Message);
			break;
		case CMD_SET_ID:
			return resGetState();
			break;
		case CMD_GET_STATE:
			return resGetState();
			break;
		case CMD_GET_BAT_LEVEL:
			return resBatLevel();
			break;
		case CMD_START_CHARGE:
			return resStartCharge();
			break;
		case CMD_STOP_CHARGE:
			return resStopCharge();
			break;
		default:
			return ERROR;
			break;
	}
}

static void packetProcesssing(uint8_t dataRec) {
	static uint16_t len=0,headerPacket=0;

	switch (stateRev)
	{
	case STATE_REC_HEADER:
		len=0;
		if(dataRec==0xFA){
			headerPacket=0xFA;
		}
		if(headerPacket==0xFA){
			if(dataRec==0x55){
				headerPacket=0;
				stateRev=STATE_REC_DATA;
			}
		}
		else{
			headerPacket=0;
		}
		break;
	case STATE_REC_DATA:
		if(len < 3){
			saveData[len] = dataRec;
			len++;
		}
		else{
			if(len < commonPack.length){
				saveData[len] = dataRec;
				len++;
				if (len == commonPack.length)
				{
					if (saveData[len-1] == calChecksum((uint8_t *)&commonPack, commonPack.length - 1))
					{
						if(SUCCESS == processCmd(&commonPack)){

						}
						else{
//							cmdResponse(commonPack.command+1, NACK);
						}
					}
					else
					{
						cmdResponse(commonPack.command+1, NACK);
					}
					stateRev = STATE_REC_HEADER;
				}
			}
		}
		break;
	default:
		break;
	}
}

static void cmdResponse(uint8_t cmd,uint8_t ackRes) {
	memset(&response,0,sizeof(response));
	response.header=0x55FA;
	response.command = cmd;
	response.length = 5;
	response.ack=ackRes;
	response.crc = calChecksum((uint8_t *)&response+2, sizeof(response) - 3);
	write((uint8_t *)&response, sizeof(response));
}

static void cmdResponse_(uint8_t cmd,uint8_t ackRes,uint8_t *data,uint32_t len) {
	uint8_t bufTamp[sizeof(response)+len];
	FrameResponseFormat_t *res = (FrameResponseFormat_t*)&bufTamp;
	res->header = 0x55FA;
	res->command = cmd;
	res->length = 5 + len;
	res->ack = ackRes;
	memcpy(&bufTamp[6],data,len);
	bufTamp[res->length + 1] = calChecksum(&bufTamp[2],res->length - 1);
	write(bufTamp, sizeof(bufTamp));
}

static uint8_t calChecksum(uint8_t* data, uint32_t len) {
	uint32_t i;
	uint8_t chck_sum = 0;

	for(i = 0; i < len; i++) {
		chck_sum += *(data + i);
	}
	chck_sum = ~chck_sum + 1;
	return chck_sum;
}


static uint32_t write(uint8_t* buf, uint32_t length) {
	HAL_UART_Transmit_IT(&huart1,buf, length);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	if(huart->Instance == USART1){
		packetProcesssing(dataRx);
		HAL_UART_Receive_IT(huart, &dataRx, 1);
	}
}

